export class AppConfig {
    public static API_URL: string = "http://carfleet2.azurewebsites.net/";
}