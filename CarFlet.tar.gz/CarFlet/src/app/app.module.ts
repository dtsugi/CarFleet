import { NgModule } from '@angular/core';
import { IonicApp, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';

// Pages
import { HelloIonicPage } from '../pages/hello-ionic/hello-ionic';
import { ItemDetailsPage } from '../pages/item-details/item-details';
import { ListPage } from '../pages/list/list';
import { LoginPage } from '../pages/login/login';
import { AsistenteVirtualHomePage } from '../pages/asistente-virtual/asistente-virtual-home';
import { HabitosConduccionHomePage } from '../pages/habitos-conduccion/habitos-conduccion-home';
import { CalculosConsumosPage } from '../pages/habitos-conduccion/calculos-consumos/calculos-consumos';

@NgModule({
  declarations: [
    MyApp,
    HelloIonicPage,
    ItemDetailsPage,
    ListPage,
    LoginPage,
    AsistenteVirtualHomePage,
    HabitosConduccionHomePage,
    CalculosConsumosPage
  ],
  imports: [
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HelloIonicPage,
    ItemDetailsPage,
    ListPage,
    LoginPage,
    AsistenteVirtualHomePage,
    HabitosConduccionHomePage,
    CalculosConsumosPage
  ],
  providers: []
})
export class AppModule { }
