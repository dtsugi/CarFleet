import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { CalculosConsumosPage } from './calculos-consumos/calculos-consumos';

@Component({
  templateUrl: 'habitos-conduccion-home.html'
})
export class HabitosConduccionHomePage {
  constructor(public navCtrl: NavController, public navParams: NavParams) {

  }

  tappedMenu(event) {
    this.navCtrl.push(CalculosConsumosPage);
  }
}
