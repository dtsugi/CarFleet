import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
    templateUrl: 'lugares-frecuentados.html'
})
export class LugaresFrecuentadosPage {
    constructor(public navCtrl: NavController, public navParams: NavParams) {

    }
}
