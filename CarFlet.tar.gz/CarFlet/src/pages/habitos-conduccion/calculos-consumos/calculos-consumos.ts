import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
    templateUrl: 'calculos-consumos.html'
})
export class CalculosConsumosPage {
    constructor(public navCtrl: NavController, public navParams: NavParams) {

    }
}
