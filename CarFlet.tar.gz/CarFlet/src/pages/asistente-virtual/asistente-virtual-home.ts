import { Component } from '@angular/core';


@Component({
  templateUrl: 'asistente-virtual-home.html'
})
export class AsistenteVirtualHomePage {
  constructor() {

  }
}
