export const MAINTENANCE_OPERATION_LIST = [
  {
    "Id": "18",
    "Name": "Cambio de aceite"
  },
  {
    "Id": "19",
    "Name": "Cambio de filtro de aceite"
  },
  {
    "Id": "20",
    "Name": "Cambio del filtro de aire"
  },
  {
    "Id": "21",
    "Name": "Cambio del filtro de habitáculo"
  },
  {
    "Id": "22",
    "Name": "Cambio de bujías"
  },
  {
    "Id": "23",
    "Name": "Cambio de neumáticos"
  },
  {
    "Id": "24",
    "Name": "Cambio de amortiguadores"
  },
  {
    "Id": "25",
    "Name": "Revisión en taller"
  },
  {
    "Id": "26",
    "Name": "Prueba revisión"
  },
  {
    "Id": "27",
    "Name": "Mirar presión neumáticos"
  },
  {
    "Id": "28",
    "Name": "Cambio de aceite"
  },
  {
    "Id": "29",
    "Name": "Cambio de filtro de aceite"
  },
  {
    "Id": "30",
    "Name": "Cambio del filtro de aire"
  },
  {
    "Id": "31",
    "Name": "Cambio del filtro de habitáculo"
  },
  {
    "Id": "32",
    "Name": "Cambio de bujías"
  },
  {
    "Id": "33",
    "Name": "Cambio de neumáticos"
  },
  {
    "Id": "34",
    "Name": "Cambio de amortiguadores"
  },
  {
    "Id": "35",
    "Name": "Revisión en taller"
  },
  {
    "Id": "36",
    "Name": "Cambio de aceite"
  },
  {
    "Id": "37",
    "Name": "Cambio de filtro de aceite"
  },
  {
    "Id": "38",
    "Name": "Cambio del filtro de aire"
  },
  {
    "Id": "39",
    "Name": "Cambio del filtro de habitáculo"
  },
  {
    "Id": "40",
    "Name": "Cambio de bujías"
  },
  {
    "Id": "41",
    "Name": "Cambio de neumáticos"
  },
  {
    "Id": "42",
    "Name": "Cambio de amortiguadores"
  },
  {
    "Id": "43",
    "Name": "Revisión en taller"
  },
  { "Id": "44" },
  {
    "Id": "45",
    "Name": "cambio conductor"
  },
  {
    "Id": "46",
    "Name": "Veterinario"
  },
  {
    "Id": "47",
    "Name": "TACOGRAFO NUEVO"
  },
  {
    "Id": "48",
    "Name": "Cambio de aceite"
  },
  {
    "Id": "49",
    "Name": "Cambio de filtro de aceite"
  },
  {
    "Id": "50",
    "Name": "Cambio del filtro de aire"
  },
  {
    "Id": "51",
    "Name": "Cambio del filtro de habitáculo"
  },
  {
    "Id": "52",
    "Name": "Cambio de bujías"
  },
  {
    "Id": "53",
    "Name": "Cambio de neumáticos"
  },
  {
    "Id": "54",
    "Name": "Cambio de amortiguadores"
  },
  {
    "Id": "55",
    "Name": "Revisión en taller"
  }
];