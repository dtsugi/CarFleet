export var AppConfig = (function () {
    function AppConfig() {
    }
    AppConfig.API_URL = "http://carfleet2.azurewebsites.net/";
    return AppConfig;
}());
//# sourceMappingURL=app.config.js.map