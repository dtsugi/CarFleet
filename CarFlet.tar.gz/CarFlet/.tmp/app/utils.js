export var Utils = (function () {
    function Utils() {
    }
    Utils.IsValidApiParameter = function (parameter) {
        if (parameter === undefined || parameter == "null") {
            parameter = null;
        }
        return parameter;
    };
    Utils.SetUrlApiGet = function (url, parameters) {
        for (var i = 0; i < parameters.length; i++) {
            url += parameters[i] + "/";
        }
        return url;
    };
    return Utils;
}());
export var COMPANY_ID_LS = "companyIdLS";
//# sourceMappingURL=utils.js.map