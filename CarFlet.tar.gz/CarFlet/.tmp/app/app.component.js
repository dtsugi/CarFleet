var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild } from '@angular/core';
import { Platform, MenuController, Nav } from 'ionic-angular';
import { StatusBar } from 'ionic-native';
import { PageMenu } from '../models/PageMenu';
import { LoginPage } from '../pages/login/login';
import { AsistenteVirtualHomePage } from '../pages/asistente-virtual/asistente-virtual-home';
import { HabitosConduccionHomePage } from '../pages/habitos-conduccion/habitos-conduccion-home';
import { OtrosHomePage } from '../pages/otros/otros-home';
export var MyApp = (function () {
    function MyApp(platform, menu) {
        this.platform = platform;
        this.menu = menu;
        // make HelloIonicPage the root (or first) page
        // rootPage: any = LoginPage;
        this.rootPage = LoginPage;
        this.initializeApp();
        this.pages = [];
        // set our app's pages
        this.pages.push(new PageMenu('Mi compañia', OtrosHomePage, 'home'));
        this.pages.push(new PageMenu('Asistente Virtual', AsistenteVirtualHomePage, 'ionitron'));
        this.pages.push(new PageMenu('Hábitos de conduccion', HabitosConduccionHomePage, "car"));
        this.pages.push(new PageMenu('Diagnosis y averias', null, 'construct'));
        this.pages.push(new PageMenu('GPS', null, 'locate'));
        this.pages.push(new PageMenu('Gestion de la documentacion', null, 'document'));
        this.pages.push(new PageMenu('Multas', null, 'card'));
        this.pages.push(new PageMenu('Panel de conduccion en tiempo real', null, 'speedometer'));
        this.pages.push(new PageMenu('Cerrar sesion', LoginPage, 'log-out'));
        // this.pages.push(new PageMenu('Otros', OtrosHomePage, 'more'));
    }
    MyApp.prototype.initializeApp = function () {
        this.platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            StatusBar.styleDefault();
        });
    };
    MyApp.prototype.openPage = function (page) {
        // close the menu when clicking a link from the menu
        this.menu.close();
        // navigate to the new page if it is not the current page
        this.nav.setRoot(page.Component);
    };
    __decorate([
        ViewChild(Nav), 
        __metadata('design:type', (typeof (_a = typeof Nav !== 'undefined' && Nav) === 'function' && _a) || Object)
    ], MyApp.prototype, "nav", void 0);
    MyApp = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/app/app.html"*/'<ion-menu [content]="content">\n\n  <ion-header>\n    <ion-toolbar>\n      <ion-title>Pages</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n\n\n  <ion-content>\n    <ion-list>\n      <button ion-item icon-left *ngFor="let p of pages" (click)="openPage(p)">\n        <ion-icon name="{{p.IconName}}"></ion-icon>\n        {{p.Title}}\n      </button>\n    </ion-list>\n  </ion-content>\n\n</ion-menu>\n\n<ion-nav [root]="rootPage" #content swipeBackEnabled="false"></ion-nav>\n'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/app/app.html"*/
        }), 
        __metadata('design:paramtypes', [(typeof (_b = typeof Platform !== 'undefined' && Platform) === 'function' && _b) || Object, (typeof (_c = typeof MenuController !== 'undefined' && MenuController) === 'function' && _c) || Object])
    ], MyApp);
    return MyApp;
    var _a, _b, _c;
}());
//# sourceMappingURL=app.component.js.map