var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FleetService } from '../../../services/fleet.service';
import { COMPANY_ID_LS } from '../../../app/utils';
export var FleetListPage = (function () {
    function FleetListPage(navCtrl, navParams, _fleetService) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this._fleetService = _fleetService;
        this.fleetList = [];
    }
    FleetListPage.prototype.ngOnInit = function () {
        this.initFleetList();
    };
    FleetListPage.prototype.initFleetList = function () {
        var companyId = localStorage.getItem(COMPANY_ID_LS);
        this.fleetList = this._fleetService.get(null, companyId);
    };
    FleetListPage.prototype.searchFleet = function (ev) {
        this.initFleetList();
        var val = ev.target.value;
        if (val && val.trim() != '') {
            this.fleetList = this.fleetList.filter(function (item) {
                return (item.Name.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
    };
    FleetListPage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/fleet/fleet-list.html"*/'<ion-header>\n    <ion-navbar>\n        <ion-title>Lista de flotas</ion-title>\n    </ion-navbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar (ionInput)="searchFleet($event)"></ion-searchbar>\n    <ion-list>\n        <ion-item *ngFor="let fleet of fleetList">\n            <ion-label>{{fleet.Name}}</ion-label>\n        </ion-item>\n    </ion-list>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/fleet/fleet-list.html"*/,
            providers: [FleetService]
        }), 
        __metadata('design:paramtypes', [NavController, NavParams, FleetService])
    ], FleetListPage);
    return FleetListPage;
}());
//# sourceMappingURL=fleet-list.js.map