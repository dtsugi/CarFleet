var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { DriverService } from '../../../services/driver.service';
import { DriverViewPage } from './driver-view';
import { COMPANY_ID_LS } from '../../../app/utils';
export var DriverListPage = (function () {
    function DriverListPage(navCtrl, navParams, _driverService) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this._driverService = _driverService;
        this.driverList = [];
    }
    DriverListPage.prototype.ngOnInit = function () {
        this.initDriverList();
    };
    DriverListPage.prototype.viewDriver = function (driver) {
        this.navCtrl.push(DriverViewPage, { driverSelected: driver });
    };
    DriverListPage.prototype.initDriverList = function () {
        var companyId = localStorage.getItem(COMPANY_ID_LS);
        this.driverList = this._driverService.get(null, companyId);
    };
    DriverListPage.prototype.searchDriver = function (ev) {
        this.initDriverList();
        var val = ev.target.value;
        if (val && val.trim() != '') {
            this.driverList = this.driverList.filter(function (item) {
                return (item.Name.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
    };
    DriverListPage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/driver/driver-list.html"*/'<ion-header>\n    <ion-navbar>\n        <ion-title>Lista de conductores</ion-title>\n    </ion-navbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar (ionInput)="searchDriver($event)"></ion-searchbar>\n    <ion-list>\n        <ion-item *ngFor="let driver of driverList" (click)="viewDriver(driver)">\n            <ion-avatar item-left>\n                <img src="assets/img/driverListIcon.png">\n            </ion-avatar>\n            <h2 [innerHTML]="driver.Name"></h2>\n            <h3 [innerHTML]="driver.Surname"></h3>\n            <p [innerHTML]="driver.Personal_id"></p>\n        </ion-item>\n    </ion-list>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/driver/driver-list.html"*/,
            providers: [DriverService]
        }), 
        __metadata('design:paramtypes', [NavController, NavParams, DriverService])
    ], DriverListPage);
    return DriverListPage;
}());
//# sourceMappingURL=driver-list.js.map