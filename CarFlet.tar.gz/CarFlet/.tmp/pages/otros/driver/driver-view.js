var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
export var DriverViewPage = (function () {
    function DriverViewPage(navCtrl, navParams) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
    }
    DriverViewPage.prototype.ngOnInit = function () {
        this.driver = this.navParams.get("driverSelected");
    };
    DriverViewPage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/driver/driver-view.html"*/'<ion-header>\n    <ion-navbar>\n        <ion-title>Informacion de conductor</ion-title>\n    </ion-navbar>\n</ion-header>\n<ion-content>\n    <ion-item>\n        <ion-icon name="person" item-left large></ion-icon>\n        <h2>{{driver.Name}} {{driver.Surname}} </h2>\n        <h4><b>Nombre completo</b></h4>\n    </ion-item>\n    <ion-item>\n        <ion-icon name="information" item-left large></ion-icon>\n        <h2>{{driver.Personal_id}} </h2>\n        <h4><b>Id Personal</b></h4>\n    </ion-item>\n    <ion-item>\n        <ion-icon name="call" item-left large></ion-icon>\n        <h2>{{driver.Phone_number}} </h2>\n        <h4><b>Numero de telefono</b></h4>\n    </ion-item>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/driver/driver-view.html"*/
        }), 
        __metadata('design:paramtypes', [NavController, NavParams])
    ], DriverViewPage);
    return DriverViewPage;
}());
//# sourceMappingURL=driver-view.js.map