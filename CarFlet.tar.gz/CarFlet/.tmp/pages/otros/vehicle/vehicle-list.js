var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { VehicleService } from '../../../services/vehicle.service';
import { VehicleViewPage } from './vehicle-view';
import { COMPANY_ID_LS } from '../../../app/utils';
export var VehicleListPage = (function () {
    function VehicleListPage(navCtrl, navParams, _vehicleService) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this._vehicleService = _vehicleService;
        this.vehicleList = [];
    }
    VehicleListPage.prototype.ngOnInit = function () {
        this.initVehicleList();
    };
    VehicleListPage.prototype.viewVehicle = function (vehicle) {
        console.log(vehicle);
        this.navCtrl.push(VehicleViewPage, { vehicleSelected: vehicle });
    };
    VehicleListPage.prototype.initVehicleList = function () {
        var companyId = localStorage.getItem(COMPANY_ID_LS);
        this.vehicleList = this._vehicleService.get(null, companyId, null, null, null);
    };
    VehicleListPage.prototype.searchVehicle = function (ev) {
        this.initVehicleList();
        var val = ev.target.value;
        if (val && val.trim() != '') {
            this.vehicleList = this.vehicleList.filter(function (item) {
                return (item.Name.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
    };
    VehicleListPage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/vehicle/vehicle-list.html"*/'<ion-header>\n    <ion-navbar>\n        <ion-title>Lista de vehiculos</ion-title>\n    </ion-navbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar (ionInput)="searchVehicle($event)"></ion-searchbar>\n    <ion-list>\n        <ion-item *ngFor="let vehicle of vehicleList" (click)="viewVehicle(vehicle)">\n            <ion-avatar item-left>\n                <img src="assets/img/vehicleListIcon.png">\n            </ion-avatar>\n            Name:\n            <h2 [innerHTML]="vehicle.Name"></h2>\n            Model:\n            <h3 [innerHTML]="vehicle.Model"></h3>\n            Year:\n            <p [innerHTML]="vehicle.Year"></p>\n        </ion-item>\n    </ion-list>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/otros/vehicle/vehicle-list.html"*/,
            providers: [VehicleService]
        }), 
        __metadata('design:paramtypes', [NavController, NavParams, VehicleService])
    ], VehicleListPage);
    return VehicleListPage;
}());
//# sourceMappingURL=vehicle-list.js.map