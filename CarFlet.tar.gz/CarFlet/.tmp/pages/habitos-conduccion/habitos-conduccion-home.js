var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { CalculosConsumosPage } from './calculos-consumos/calculos-consumos';
export var HabitosConduccionHomePage = (function () {
    function HabitosConduccionHomePage(navCtrl, navParams) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
    }
    HabitosConduccionHomePage.prototype.tappedMenu = function (event) {
        this.navCtrl.push(CalculosConsumosPage);
    };
    HabitosConduccionHomePage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/habitos-conduccion/habitos-conduccion-home.html"*/'<ion-header>\n    <ion-navbar>\n        <button ion-button menuToggle>\n      <ion-icon name="menu"></ion-icon>\n    </button>\n        <ion-title>Home asistente virtual</ion-title>\n    </ion-navbar>\n</ion-header>\n<ion-content>\n    \n\n    <ion-list>\n        <ion-item (click)="tappedMenu($event)">\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_I.png">\n            </ion-thumbnail>\n            <h2>Calculos de consumos</h2>\n            <!--<p>Hayao Miyazaki ? 1988</p>\n            <button clear item-right>View</button>-->\n        </ion-item>\n\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_IV.png">\n            </ion-thumbnail>\n            <h2>Aceleraciones y frenadas</h2>\n        </ion-item>\n\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_II.png">\n            </ion-thumbnail>\n            <h2>Rutas diarias</h2>\n        </ion-item>\n\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_VI.png">\n            </ion-thumbnail>\n            <h2>Lugares frecuentados</h2>\n        </ion-item>\n\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_III.png">\n            </ion-thumbnail>\n            <h2>Eficiencia de conducción</h2>\n        </ion-item>\n\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/HabitosConduccion_I.png">\n            </ion-thumbnail>\n            <h2>Análisis de vías</h2>\n        </ion-item>\n    </ion-list>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/habitos-conduccion/habitos-conduccion-home.html"*/
        }), 
        __metadata('design:paramtypes', [(typeof (_a = typeof NavController !== 'undefined' && NavController) === 'function' && _a) || Object, (typeof (_b = typeof NavParams !== 'undefined' && NavParams) === 'function' && _b) || Object])
    ], HabitosConduccionHomePage);
    return HabitosConduccionHomePage;
    var _a, _b;
}());
//# sourceMappingURL=habitos-conduccion-home.js.map