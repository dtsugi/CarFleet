var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CompanyService } from '../../services/company.service';
import { HomePage } from '../home/home';
import { COMPANY_ID_LS } from '../../app/utils';
export var LoginPage = (function () {
    function LoginPage(navCtrl, _companyService) {
        this.navCtrl = navCtrl;
        this._companyService = _companyService;
        this.companyList = [];
    }
    LoginPage.prototype.ngOnInit = function () {
        this.initCompanyList();
    };
    LoginPage.prototype.initCompanyList = function () {
        this.companyList = this._companyService.get(null, null, null, null);
    };
    LoginPage.prototype.login = function () {
        console.log(this.companySelected);
        if (this.companySelected === undefined) {
            console.log("IS UNDEFINED");
            this.companySelected = null;
        }
        localStorage.setItem(COMPANY_ID_LS, this.companySelected);
        console.log(localStorage.getItem(COMPANY_ID_LS));
        this.navCtrl.setRoot(HomePage);
    };
    LoginPage = __decorate([
        Component({
            selector: 'page-home',template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/login/login.html"*/'<ion-header>\n  <ion-navbar>\n    <!--<button ion-button menuToggle>\n      <ion-icon name="menu"></ion-icon>\n    </button>-->\n    <ion-title>Login</ion-title>\n  </ion-navbar>\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label floating>Nombre de usuario</ion-label>\n    <ion-input type="text"></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label floating>Password</ion-label>\n    <ion-input type="password"></ion-input>\n  </ion-item>\n  <br>\n  <ion-item>\n    <ion-label>Company</ion-label>\n    <ion-select [(ngModel)]="companySelected">\n      <ion-option *ngFor="let company of companyList" [value]="company.Id">{{company.Name}}</ion-option>\n    </ion-select>\n  </ion-item>\n  <br>\n  <button ion-button full (click)="login()">Login</button>\n  <br>\n  <p style="color:red;text-align:center">Recuerde que si selecciona alguna compañia algunos resultados de las vistas se pueden ver afectados</p>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/login/login.html"*/,
            providers: [CompanyService]
        }), 
        __metadata('design:paramtypes', [(typeof (_a = typeof NavController !== 'undefined' && NavController) === 'function' && _a) || Object, (typeof (_b = typeof CompanyService !== 'undefined' && CompanyService) === 'function' && _b) || Object])
    ], LoginPage);
    return LoginPage;
    var _a, _b;
}());
//# sourceMappingURL=login.js.map