var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AsistenciaConductorPage } from './asistencia-conductor/asistencia-conductor';
export var AsistenteVirtualHomePage = (function () {
    function AsistenteVirtualHomePage(navCtrl, navParams) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
    }
    AsistenteVirtualHomePage.prototype.goToAsistenciaConductor = function () {
        this.navCtrl.push(AsistenciaConductorPage);
    };
    AsistenteVirtualHomePage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/asistente-virtual/asistente-virtual-home.html"*/'<ion-header>\n    <ion-navbar>\n        <button ion-button menuToggle>\n      <ion-icon name="menu"></ion-icon>\n    </button>\n        <ion-title>Home asistente virtual</ion-title>\n    </ion-navbar>\n</ion-header>\n<ion-content>\n    <ion-card class="sectionCard">\n        <img src="assets/img/AsistenteVirtual_I.jpg" class="sectionCard-img" />\n        <div class="sectionCard-title">Gestión de las operaciones de mantenimiento del vehículo</div>\n    </ion-card>\n    <br>\n    <ion-card class="sectionCard" (click)="goToAsistenciaConductor()">\n        <img src="assets/img/AsistenteVirtual_II.jpg" class="sectionCard-img" />\n        <div class="sectionCard-title">Asistencia al conductor </div>\n    </ion-card>\n\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/asistente-virtual/asistente-virtual-home.html"*/
        }), 
        __metadata('design:paramtypes', [NavController, NavParams])
    ], AsistenteVirtualHomePage);
    return AsistenteVirtualHomePage;
}());
//# sourceMappingURL=asistente-virtual-home.js.map