var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { SlidesAsistenciaPage } from './slides-asistencia/slides-asistencia';
export var AsistenciaConductorPage = (function () {
    function AsistenciaConductorPage(navCtrl, navParams) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
    }
    AsistenciaConductorPage.prototype.tappedMenu = function (slideSelected) {
        console.log("slideSelected" + slideSelected);
        this.navCtrl.push(SlidesAsistenciaPage, { slideSelected: slideSelected });
    };
    AsistenciaConductorPage = __decorate([
        Component({template:/*ion-inline-start:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/asistente-virtual/asistencia-conductor/asistencia-conductor.html"*/'<ion-header>\n    <ion-navbar>\n        <button ion-button menuToggle>\n      <ion-icon name="menu"></ion-icon>\n    </button>\n        <ion-title>Home asistencia al conductor</ion-title>\n    </ion-navbar>\n</ion-header>\n<ion-content>\n    <ion-list>\n        <ion-item (click)="tappedMenu(0)">\n            <ion-thumbnail item-left>\n                <img src="assets/img/AsistenciaConductor_I.png">\n            </ion-thumbnail>\n            <h2>Primeros auxilios</h2>\n        </ion-item>\n        <ion-item (click)="tappedMenu(1)">\n            <ion-thumbnail item-left>\n                <img src="assets/img/AsistenciaConductor_II.png">\n            </ion-thumbnail>\n            <h2>Actuación en caso de accidente</h2>\n        </ion-item>\n        <ion-item>\n            <ion-thumbnail item-left>\n                <img src="assets/img/AsistenciaConductor_III.png">\n            </ion-thumbnail>\n            <h2>Cambio de neumático pinchado</h2>\n        </ion-item>\n    </ion-list>\n</ion-content>'/*ion-inline-end:"/mnt/hd_xvdb/WORKSPACES/CarFlet/src/pages/asistente-virtual/asistencia-conductor/asistencia-conductor.html"*/
        }), 
        __metadata('design:paramtypes', [NavController, NavParams])
    ], AsistenciaConductorPage);
    return AsistenciaConductorPage;
}());
//# sourceMappingURL=asistencia-conductor.js.map