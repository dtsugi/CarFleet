export var PageMenu = (function () {
    function PageMenu(title, component, iconName) {
        this.Title = title;
        this.Component = component;
        this.IconName = iconName;
    }
    return PageMenu;
}());
//# sourceMappingURL=PageMenu.js.map